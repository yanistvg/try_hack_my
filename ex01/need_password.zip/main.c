#include <stdio.h>
#include <string.h>

void success (void);

const char passwd[20] = "@dmin!";

int main (void)
{
  char buffer[200];

  do
  {
    bzero (buffer, sizeof (char) * 200);
    printf ("Entrer le mot de passe : ");
    scanf (" %s", buffer);
  } while (strcmp (buffer, passwd) != 0);
  success ();
  return 0;
}

void success (void)
{
  printf ("Tu a reussie a trouver le bon mot de passe\n");
  printf ("pour le fichier compresse le mot de passe est : FLAG_FIRST_PASS\n");
}